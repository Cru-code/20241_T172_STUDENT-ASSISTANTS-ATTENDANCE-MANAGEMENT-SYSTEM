namespace ZKTecoIntegration.Models
{
    public class UserInfo
    {
        public string EnrollNumber { get; set; }
        public string Name { get; set; }
        public int Privilege { get; set; }
        public bool Enabled { get; set; }
    }
}
