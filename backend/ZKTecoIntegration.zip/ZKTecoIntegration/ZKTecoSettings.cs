namespace ZKTecoIntegration
{
    public class ZKTecoSettings
    {
        public string DeviceIpAddress { get; set; }
        public int DevicePort { get; set; }
        public int MachineNumber { get; set; }
    }
}
