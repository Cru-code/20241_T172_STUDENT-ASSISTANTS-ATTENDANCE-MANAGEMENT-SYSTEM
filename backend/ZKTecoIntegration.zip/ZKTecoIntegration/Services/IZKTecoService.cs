namespace ZKTecoIntegration.Services
{
    public interface IZKTecoService
    {
        bool Connect(string ipAddress, int port);
    }
}
